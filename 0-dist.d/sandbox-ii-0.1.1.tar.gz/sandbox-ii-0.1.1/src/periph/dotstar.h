// Sat Jul 29 18:14:02 UTC 2017
// 4735-b0b-01-

extern void setup_dotstar();
extern void loop_dotstar();
