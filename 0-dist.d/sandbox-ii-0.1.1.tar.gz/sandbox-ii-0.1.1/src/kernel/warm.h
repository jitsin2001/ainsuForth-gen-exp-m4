// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

// prototypes - this word
extern const char warm_str[]; // = "warm";
extern void _warm(void);

