// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

extern const char plus_loop_sys_str[]; // = "plus_loop-sys";
extern void _plus_loop_sys(void);
extern void dStack_push(cell_t value);
extern void rStack_push(cell_t value);
extern cell_t dStack_pop(void);
extern cell_t rStack_pop(void);
extern cell_t* ip;
extern void _throw(void);

