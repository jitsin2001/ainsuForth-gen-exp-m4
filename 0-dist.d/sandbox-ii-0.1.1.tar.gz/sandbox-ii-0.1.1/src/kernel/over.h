// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

// prototypes - this word
extern const char over_str[]; // = "over";
extern void _over(void);

// prototypes - external functions
extern void dStack_push(cell_t value);
extern cell_t dStack_peek(int n);
