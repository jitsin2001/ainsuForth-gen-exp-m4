// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

// prototypes - this word
extern const char exit_str[]; // = "exit";
extern void _exit(void);

// prototypes - variables
extern cell_t* ip;   // Instruction Pointer

// prototypes - external functions
extern cell_t rStack_pop(void);

