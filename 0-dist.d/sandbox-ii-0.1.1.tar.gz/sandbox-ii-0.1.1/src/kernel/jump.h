// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

// prototypes - this word
extern const char jump_str[]; // = "jump";
extern void _jump(void);

// prototypes - variables
extern cell_t* ip;   // Instruction Pointer

