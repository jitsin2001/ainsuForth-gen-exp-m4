// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

extern const char quit_str[]; // = "quit";
extern void _quit(void);
extern void rStack_clear(void);
extern char* cpToIn;

