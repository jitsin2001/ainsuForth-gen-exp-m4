// Sun 17 Jun 22:09:15 UTC 2018
// 4737-a3a-0e0-
char junk;
// TODO: move some of this stuff elsewhere - way beyond the scope of the getline word.
#ifndef DEF_GETLINE_CPP_ONCE
    #define DEF_GETLINE_CPP_ONCE
    #include "getline_options.h"

    // #warning HERE_WE_ARE in getline.cpp

    #ifdef NEVER_DEFINED_TEN_FOUR // nonsense tag to prevent compile
        #warning NEVER_DEFINED_TEN_FOUR defined in getline.cpp
    #endif // #ifdef NEVER_DEFINED_TEN_FOUR - line 6
#endif // #ifndef DEF_GETLINE_CPP_ONCE
// END.
