// Thu Aug  3 18:43:18 UTC 2017
// 4735-b0e-05-

// prototypes - this word
extern const char download_str[]; // = "download"; // main forth vocabulary
extern const char dl_ends_str[];  // = "endeth";   // download vocabulary

extern void _download(void);
extern void _dl_ends(void);

extern uint8_t noInterpreter; // = FALSE ;

// not here - look elsewhere: // extern void write_a_capture_file(void);

// end.


// getline.cpp:void write_a_capture_file(void) {

