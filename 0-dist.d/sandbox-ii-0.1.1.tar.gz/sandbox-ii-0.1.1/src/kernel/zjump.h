// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

extern const char zjump_str[]; // = "zjump";
extern void _zjump(void);
extern cell_t dStack_pop(void);
extern cell_t* ip;

