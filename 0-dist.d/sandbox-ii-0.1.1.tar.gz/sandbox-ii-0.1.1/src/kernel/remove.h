// Fri Nov 24 23:31:39 UTC 2017
// 4735-b0c-09b-   the -09x- is new Nov 24, 2017.

// previous timestamp:
// none.

// prototypes - this word
extern const char remove_str[]; // = "remove";

extern void _remove(void);

