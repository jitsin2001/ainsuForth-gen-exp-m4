// Fri Jun  9 02:32:35 UTC 2017
// 4735-a0f

extern const char subroutine_str[]; // = "subroutine";
extern void _subroutine(void);
extern cell_t* pDoes;
extern cell_t* ip;

