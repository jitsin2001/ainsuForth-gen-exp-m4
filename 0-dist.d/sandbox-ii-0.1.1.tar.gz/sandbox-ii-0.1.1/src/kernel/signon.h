// Tue Jun 20 21:33:06 UTC 2017
// 4735-a0p-02-

// external const
extern const flashEntry_t* pFlashEntry; // = flashDict;   // Pointer into the flash Dictionary

// prototypes - this word
extern void signOn(void);

// prototypes - variables
extern cell_t w;     // Working Register

