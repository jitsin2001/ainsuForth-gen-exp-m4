// Sun Jun 11 23:00:12 UTC 2017
// 4735-a0g

// prototypes - this word
extern const char drop_str[]; // = "drop";
extern void _drop(void);

// prototypes - variables
// extern cell_t* ip;   // Instruction Pointer

// prototypes - external functions
extern cell_t dStack_pop(void);

