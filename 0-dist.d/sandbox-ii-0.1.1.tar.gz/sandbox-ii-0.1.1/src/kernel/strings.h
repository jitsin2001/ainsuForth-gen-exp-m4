// Tue Jun 20 21:33:06 UTC 2017
// 4735-a0p-02-

extern const char sp_str[]; // = " ";
extern const char hexidecimal_str[]; // = "$";
extern const char octal_str[]; // = "0";
extern const char binary_str[]; // = "%";

// prototypes - this word
extern void displayValue(void);

// prototypes - variables
extern cell_t w;     // Working Register
extern uint8_t base;  // stores the number conversion radix

