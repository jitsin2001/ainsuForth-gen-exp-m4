// Thu Jun 22 20:49:39 UTC 2017
// 4735-a0p-04-

extern const char dump_str[]; // = "dump";
extern void _dump(void);
extern const char sp_str[]; // = " ";
extern const char zero_str[]; // = "0";

/******************************************************************************/
/**  YAFFA - Yet Another Forth for Arduino                                   **/
/**                                                                          **/
/**  File: Dictionary.ino                                                    **/
/**  Copyright (C) 2012 Stuart Wood (swood@rochester.rr.com)                 **/
/******************************************************************************/
