// Wed Jun 21 20:55:05 UTC 2017
// 4735-a0p-03-

extern char* xtToName(cell_t xt);

extern userEntry_t* pLastUserEntry; // = NULL;
extern userEntry_t* pUserEntry; // = NULL;

