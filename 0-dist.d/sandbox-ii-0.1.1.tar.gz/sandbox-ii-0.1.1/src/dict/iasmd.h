// Tue Jun 20 21:33:06 UTC 2017
// 4735-a0p-02-

extern const char plus_str[];   // = "+";
extern void _plus(void);

extern const char minus_str[];  // = "-";
extern void _minus(void);

extern const char star_str[];   // = "*";
extern void _star(void);

extern const char slash_str[];  // = "/";
extern void _slash(void);

extern const char negate_str[]; // = "negate";
extern void _negate(void);

extern const char abs_str[];    // = "abs";
extern void _abs(void);

