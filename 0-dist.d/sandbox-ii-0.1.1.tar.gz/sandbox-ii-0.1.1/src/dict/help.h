// Sat Jul 29 18:14:02 UTC 2017
// 4735-b0b-01-

extern const char help_str[]; // = "help";
extern void _help(void);

extern const char who_str[]; // = "who";
extern void _who(void);
