// Mon Jan 15 18:14:33 UTC 2018
// 4737-a0d-05c-

// version bump

// Thu Aug  3 01:46:56 UTC 2017
// 4735-b0d-00-

extern cell_t dStack_pop(void);
extern const flashEntry_t* pFlashEntry; // = flashDict;      the main forth vocabulary
extern const flashEntry_t* pDLFlashEntry; // = DLflashDict;  the download vocabulary
extern cell_t* pHere;

